import "./style/main.scss"
import Home from "./pages/home"

const App = () => {
  return (
    <div className="content-container">
      <Home />
    </div>
  )
}

export default App